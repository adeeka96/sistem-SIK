<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Tb_karyawan extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Tb_karyawan_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));

        if ($q <> '') {
            $config['base_url'] = base_url() . 'tb_karyawan/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'tb_karyawan/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'tb_karyawan/index.html';
            $config['first_url'] = base_url() . 'tb_karyawan/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Tb_karyawan_model->total_rows($q);
        $tb_karyawan = $this->Tb_karyawan_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'tb_karyawan_data' => $tb_karyawan,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $this->load->view('tb_karyawan/tb_karyawan_list', $data);
    }

    public function read($id)
    {
        $row = $this->Tb_karyawan_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_karyawan' => $row->id_karyawan,
		'id_gaji' => $row->id_gaji,
		'nip' => $row->nip,
		'nama' => $row->nama,
		'gender' => $row->gender,
		'tgl_lahir' => $row->tgl_lahir,
		'tgl_masuk' => $row->tgl_masuk,
	    );
            $this->load->view('tb_karyawan/tb_karyawan_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('tb_karyawan'));
        }
    }

    public function create()
    {
        $data = array(
            'button' => 'ADD',
            'action' => site_url('tb_karyawan/create_action'),
	    'id_karyawan' => set_value('id_karyawan'),
	    'id_gaji' => set_value('id_gaji'),
	    'nip' => set_value('nip'),
	    'nama' => set_value('nama'),
	    'gender' => set_value('gender'),
	    'tgl_lahir' => set_value('tgl_lahir'),
	    'tgl_masuk' => set_value('tgl_masuk'),
	);
        $this->load->view('tb_karyawan/tb_karyawan_form', $data);
    }

    public function create_action()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'id_gaji' => $this->input->post('id_gaji',TRUE),
		'nip' => $this->input->post('nip',TRUE),
		'nama' => $this->input->post('nama',TRUE),
		'gender' => $this->input->post('gender',TRUE),
		'tgl_lahir' => $this->input->post('tgl_lahir',TRUE),
		'tgl_masuk' => $this->input->post('tgl_masuk',TRUE),
	    );

            $this->Tb_karyawan_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('tb_karyawan'));
        }
    }

    public function update($id)
    {
        $row = $this->Tb_karyawan_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('tb_karyawan/update_action'),
		'id_karyawan' => set_value('id_karyawan', $row->id_karyawan),
		'id_gaji' => set_value('id_gaji', $row->id_gaji),
		'nip' => set_value('nip', $row->nip),
		'nama' => set_value('nama', $row->nama),
		'gender' => set_value('gender', $row->gender),
		'tgl_lahir' => set_value('tgl_lahir', $row->tgl_lahir),
		'tgl_masuk' => set_value('tgl_masuk', $row->tgl_masuk),
	    );
            $this->load->view('tb_karyawan/tb_karyawan_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('tb_karyawan'));
        }
    }

    public function update_action()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_karyawan', TRUE));
        } else {
            $data = array(
		'id_gaji' => $this->input->post('id_gaji',TRUE),
		'nip' => $this->input->post('nip',TRUE),
		'nama' => $this->input->post('nama',TRUE),
		'gender' => $this->input->post('gender',TRUE),
		'tgl_lahir' => $this->input->post('tgl_lahir',TRUE),
		'tgl_masuk' => $this->input->post('tgl_masuk',TRUE),
	    );

            $this->Tb_karyawan_model->update($this->input->post('id_karyawan', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('tb_karyawan'));
        }
    }

    public function delete($id)
    {
        $row = $this->Tb_karyawan_model->get_by_id($id);

        if ($row) {
            $this->Tb_karyawan_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('tb_karyawan'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('tb_karyawan'));
        }
    }

    public function _rules()
    {
	$this->form_validation->set_rules('id_gaji', 'id gaji', 'trim|required');
	$this->form_validation->set_rules('nip', 'nip', 'trim|required');
	$this->form_validation->set_rules('nama', 'nama', 'trim|required');
	$this->form_validation->set_rules('gender', 'gender', 'trim|required');
	$this->form_validation->set_rules('tgl_lahir', 'tgl lahir', 'trim|required');
	$this->form_validation->set_rules('tgl_masuk', 'tgl masuk', 'trim|required');

	$this->form_validation->set_rules('id_karyawan', 'id_karyawan', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "tb_karyawan.xls";
        $judul = "tb_karyawan";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Gaji");
	xlsWriteLabel($tablehead, $kolomhead++, "Nip");
	xlsWriteLabel($tablehead, $kolomhead++, "Nama");
	xlsWriteLabel($tablehead, $kolomhead++, "Gender");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Lahir");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Masuk");

	foreach ($this->Tb_karyawan_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_gaji);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nip);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nama);
	    xlsWriteLabel($tablebody, $kolombody++, $data->gender);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_lahir);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_masuk);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=tb_karyawan.doc");

        $data = array(
            'tb_karyawan_data' => $this->Tb_karyawan_model->get_all(),
            'start' => 0
        );

        $this->load->view('tb_karyawan/tb_karyawan_doc',$data);
    }

}

/* End of file Tb_karyawan.php */
/* Location: ./application/controllers/Tb_karyawan.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-10-29 04:42:54 */
/* http://harviacode.com */
